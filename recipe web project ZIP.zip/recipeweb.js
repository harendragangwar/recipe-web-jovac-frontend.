
const searchButton = document.querySelector('button');
searchButton.addEventListener('click', () => {
  const searchTerm = document.querySelector('input').value;
  
});


const printButtons = document.querySelectorAll('.print-button');
printButtons.forEach((button) => {
  button.addEventListener('click', () => {
    window.print();
  });
});


const addToFavoritesButtons = document.querySelectorAll('.add-to-favorites-button');
addToFavoritesButtons.forEach((button) => {
  button.addEventListener('click', () => {
    
  });
});


const ratingInputs = document.querySelectorAll('.rating input');
ratingInputs.forEach((input) => {
  input.addEventListener('change', () => {
    const rating = input.value;
    
  });
});
